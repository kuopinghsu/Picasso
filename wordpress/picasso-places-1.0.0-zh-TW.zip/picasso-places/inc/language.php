<?php
// Written by scripts/build-theme.py: this build is in Traditional Chinese, whatever the site's language.
return 'zh_TW';
