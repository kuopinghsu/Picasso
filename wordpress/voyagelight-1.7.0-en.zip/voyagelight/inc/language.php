<?php
// Written by scripts/build-theme.py: this build is in English, whatever the site's language.
return 'en_US';
